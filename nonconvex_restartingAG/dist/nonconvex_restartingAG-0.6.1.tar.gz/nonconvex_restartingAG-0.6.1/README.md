# nonconvex_restartingAG

This is an implementation of restarting accelerated gradient algorithm with strong rules for (high-dimensional) nonconvex sparse learning problems. The corresponding paper can be found at [arXiv](https://arxiv.org/abs/2009.10629).